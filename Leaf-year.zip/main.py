year = int(input("Enter the year:"))
if (year % 4==0):
  print("the given year is leaf year")
else:
  print(" the give year is non leaf year")
